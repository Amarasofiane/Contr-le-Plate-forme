cd partie4
python launch_server.py
