#!/usr/bin/bash
cd partie2
bash clean.sh
python database_manage.py
cd ..
gnome-terminal -e "bash -c \"bash launchserv.sh; exec bash\""
cd partie1
sleep 6
python login.py
echo "veuillez patienter , dans une minute l'interface web s'ouvrira dans firefox"
sleep 60
/usr/bin/firefox http://127.0.0.1:5000/ACCUEIL
