#!/usr/bin/bash
cd static
for image in *.svg
do
rm $image
done