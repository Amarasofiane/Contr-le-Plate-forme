#!/usr/bin/bash

crontab -l | egrep -v 'partie1' > CLI_crontab