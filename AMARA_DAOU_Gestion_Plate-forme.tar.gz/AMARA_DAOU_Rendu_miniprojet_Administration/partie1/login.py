#/usr/bin/env python3
import requests
import subprocess
import datetime
import os
import sys
import time
import re
from uuid import getnode as get_mac
#test de connection serveur
def connexion_server():
	methods = 'connexion_server'
	url = adresse + methods
	r = requests.post(url, data = None)
	return r.status_code < 400
#recuperer le chemin courant
file_rep = os.getcwd()

file_id_admin = file_rep + "/id_admin"
file_config = file_rep + "/config"
#recuperer l'adresse du serveur , premiere ligne du fichier config
fichier = open(file_config, "r")
contenu = fichier.read()
contenu = contenu.split("\n")
fichier.close()

id_administrator = 0
mac = get_mac()
adresse = contenu[0]
port = contenu[1]
adresse = 'http://' + adresse + ':' + port + '/'

#try de connection
try:
	if connexion_server():
		# try pour l'envoi de donnees au serveur
		try:
			donnees = {'mac_address': mac}
			# on verifie si la MACHINE existe deja dans la bdd
			methods = 'existe'
			url = adresse + methods
			r = requests.post(url, data = donnees)
			existe = r.text
			#si elle n'existe pas
			if existe == "non":
				#demander la saisie des infos
				mail = raw_input("Entrez le mail sur lequel vous receverez des alertes : ")
				#verifier si le format de mail a ete respectee
				chn_mail = r"^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$"
				exp_mdp = re.compile(chn_mail)
				#boucler si le mail est invalide
				while exp_mdp.search(mail) is None:
					mail = raw_input("Tapez votre mail : ")

				#inserer l'administrateur dans la table
				# par default les contrainte de l'admin sont initialiser a "non"
				defaut_value = "non"
				donnees.clear
				# envoi au serveur des info concernant l'administrateur
				donnees = {'mail': mail, 'contrainte': defaut_value}
				methods = 'insert_admin'
				url = adresse + methods
				r = requests.post(url, data = donnees)
				# on place l'id de l'adim dans le fichier
				donnees.clear()
				donnees = {'mail': mail}
				methods = 'recupererid_admin'
				url = adresse + methods
				r = requests.post(url, data = donnees)
				id_administrator = int(r.text)
				#dans le fichier id_admin de la partie 1 -> on ecrit l'id de l'admin
				fichier = open(file_id_admin, 'w')
				fichier.write(str(id_administrator) + ':')
				fichier.close()
			else:
				fichier = open(file_id_admin, "r")
				contenu = fichier.read()
				contenu = contenu.split(":")
				fichier.close()
				id_administrator = contenu[0]
				#si jamais la MACHINE existe dans la base de donnee on laisse le choix a l'utilisateur de modifier ses coordonnes
				print("modifier le mail ? : ")
				choix = raw_input("oui/non : ")
				if choix == "oui":
					#oui
					donnees.clear
					donnees = {'id_admin': id_administrator}
					# recupere l'ancien mail
					methods = 'recuperermail'
					url = adresse + methods
					r = requests.post(url, data = donnees)
					mail = r.text
					# verifier l'ancien mail
					chek_mail = raw_input("Saisir l'ancien mail : ")
					#on sort pas de la boucle si l'ancien mail ne coincide pas avec le nouveau
					while mail != chek_mail:
						chek_mail = raw_input("Saisir l'ancien mail : ")
					# il a saisie l'ancien email
					# il peut saisir maintenant son nouveau mail
					mail = raw_input("Entrez votre nouveau mail : ")
					# on teste toujours la validite du mail
					chn_mail = r"^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$"
					exp_mdp = re.compile(chn_mail)
					# tant que le mail saisie n'est pas valide il boucle
					while exp_mdp.search(mail) is None:
						mail = raw_input("Tapez votre mail : ")
					#mettre a jour les donnees a envoyer
					donnees.clear
					donnees = {'id_admin': id_administrator, 'mail': mail}
					methods = 'update_mail'
					url = adresse + methods
					r = requests.post(url, data = donnees)
					print(r.text)

			fichier = open(file_id_admin, "r")
			contenu = fichier.read()
			contenu = contenu.split(":")
			fichier.close()
			id_administrator = contenu[0]
			# on recupere les ALERTE qu'il faut recevoir
			donnees.clear
			donnees = {'id_admin': int(id_administrator)}
			methods = 'recuperercontrainte'
			url = adresse + methods
			r = requests.post(url, data = donnees)
			# const contient le type d'ALERTE que l'administrateur veut recevoir
			const = r.text
			cont_insert = ""
			# oui_non decidera si on met a jour les contraintes ou pas
			oui_non = "oui"
			# les type d'ALERTE que l'administrateur peut recevoir
			constraint = ["Debordement de processeur ?", "Temperature elevee de processeur?","depassement RAM?","depassement SWAP?","depassement disk?"]
			 #choisir les ALERTEs
			if const == "non":
					for c in constraint:
						cont_insert = cont_insert + "1"

			else:
				#si c'est deja saisi on demande si il veut modifier
				oui_non = raw_input("voulez vous modifier les ALERTEs (oui/non) : \n")
				# si il dit oui
				if oui_non == "oui":
					# il refait sont choix concernant le type d'ALERTE a recevoir
					print("choisir les ALERTEs a recevoir par mail [oui/non] \n")
					for c in constraint:
						choix = raw_input("voulez vous etre ALERTE de  {} : ".format(c))
						if choix == "oui":
							cont_insert = cont_insert + "1"
						else:
							cont_insert = cont_insert + "0"
			#si c'est pour modifier les ALERTEs ou si c'est le premier parametrage
			if oui_non == "oui":
				donnees.clear()
				donnees = {'id_admin': id_administrator, 'contrainte': cont_insert}
				methods = 'update_contrainte'
				url = adresse + methods
				r = requests.post(url, data = donnees)
				print(r.text)
			# ajout du script  crontab du  collecteur pour envoyer toute les 5 minutes les infos des sondes au serveur
		except Exception as e:
			raise e
		# ajout du script collecteur au crontab du serveur client
		print "veuillez patienter"
		# on recupere le crontab actuel
		proc = subprocess.Popen(['bash', "getcrontab.sh"])

		time.sleep(2)
		proc.kill()

		cmd = "*/1 * * * * " + "cd " + file_rep + " && " + "python " + file_rep + "/" + "collecteur.py"
		crontab_file = file_rep + "/CLI_crontab"
		fichier = open(crontab_file, 'a')
		fichier.write(cmd + '\n')
		fichier.close()
		proc = subprocess.Popen(['crontab', "CLI_crontab"])
		time.sleep(1)
		proc.kill()
except Exception as e:
	print "assurez vous que le serveur est lance avant de login"
	raise e
finally:
	sys.exit()
