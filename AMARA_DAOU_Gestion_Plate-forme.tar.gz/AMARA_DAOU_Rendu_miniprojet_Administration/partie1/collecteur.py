#/usr/bin/env python3
import datetime
import os
import sys
import time
import subprocess
import requests
from uuid import getnode as get_mac
#reprise de la fonction de connection du script "login.py"
#ainsi que les fichiers contenant la config et l'id de l'admin
def connexion_server():
	methods = 'connexion_server'
	url = adresse + methods
	r = requests.post(url, data = None)
	return r.status_code < 400

file_rep = os.getcwd()
file_id_admin = file_rep + "/id_admin"

file_config = file_rep + "/config"
fichier = open(file_config, "r")
contenu = fichier.read()
contenu = contenu.split("\n")
fichier.close()
fichier = open(file_id_admin, "r")
contenu_1 = fichier.read()
contenu_1 = contenu_1.split(":")
fichier.close()

id_administrator = contenu_1[0]
adresse = contenu[0]
port = contenu[1]
adresse = 'http://' + adresse + ':' + port + '/'
#le principe de ce script est de lancer les sondes 
#recuperer toutes les resultats recus pour les envoyer au serveur.


try:
	if connexion_server():
		try:
			print("#### appel des sondes ####")
			#on lance le script sondes.sh 
			# les donnees interessantes sont a nouveau inserer dans un fichier nome informations
			f1 = "call_sondes.sh"
			subprocess.check_output(['bash', f1])
			try:
				# on ouvre le fichier contenant les donnees a inserer (les donnees numeriques)
				fichier = open("informations","r")
				ligne = fichier.readlines()
				#parcourir le fichier ligne par ligne 
				ligne = ligne[0].split(" ")
				# variable qui va contenir l'etat du serveur
				# 1 veut dire qu'un point critique est atteint
				# 0 le point critique n'est pas atteint
				state_check = ""
				#debordement cpu
				if float(ligne[1]) > 95:
					state_check = state_check + "1"
				else:
					state_check = state_check + "0"
				#temperature cpu
				if float(ligne[3]) > 80:
					state_check = state_check + "1"
				else:
					state_check = state_check + "0"
				#debordement ram
				if float(ligne[7]) > 95:
					state_check = state_check + "1"
				else:
					state_check = state_check + "0"
				#debordement swap
				if float(ligne[11]) > 80:
					state_check = state_check + "1"
				else:
					state_check = state_check + "0"
				# saturation disk
				if float(ligne[23]) > 95:
					state_check = state_check + "1"
				else:
					state_check = state_check + "0"
			except Exception as e:
				print("erreur d'ouverture du fichier")
				raise e
			finally:
				fichier.close()
			# on recupere la date et l'heure
			date_insert = time.strftime("%Y-%m-%d %H:%M:%S")
			# on recupere l'adresse mac de la MACHINE
			mac = get_mac()
			# insertion dans la base de donnees des information collecteeq
			#envoi des information avec un request
			donnees = {'mac_address': mac, 'date_insert': date_insert,
							'avg_cpu': ligne[1], 'tmp_cpu': ligne[3],
							'ram_total': ligne[5], 'ram_used': ligne[7],
							'swap_total': ligne[9], 'swap_used': ligne[11],
							'nb_process': ligne[13], 'user_connect': ligne[15],
							'state_check': state_check, 'id_admin' : id_administrator,
							'physical_core': ligne[17], 'logical_core': ligne[19], 'disk_total' : ligne[21],
							'disk_usage' : ligne[23]}
			methods = 'insertion'
			url = adresse + methods
			r = requests.post(url, data = donnees)
			print (r.text)
		except Exception as e:
			raise e
except Exception as e:
	print "dans le collecteur -> erreur de connexion au serveur"
	raise e

finally:
	sys.exit()
