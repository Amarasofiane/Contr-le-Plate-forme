#!/usr/bin/bash
rm -rf *.db