#/usr/bin/env python3
import os
import datetime
import requests
import re
import feedparser
import BeautifulSoup
from urllib2 import urlopen


file_address_ = os.getcwd()
file_address = ''

for i in file_address_:
	if i != file_address_[len(file_address_) - 1]:
		file_address = file_address + i

file_address_rep = file_address + '4'
file_config = file_address_rep + "/config"
# on recupere l'address du server depuis le fichier de config
fichier = open(file_config, "r")
contenu = fichier.read()
contenu = contenu.split("\n")
fichier.close()




# scripte qui recupere les 5 dernieres ALERTEs du cert

# on recupere le flux rss
myParser = feedparser.parse('http://www.cert.ssi.gouv.fr/site/cert-fr.rss')
# adresse du serveur centrale 
adresse = contenu[0]
port = contenu[1]
adresse = 'http://' + adresse + ':' + port + '/'

# compteur du nombre d'ALERTE recupere
nb_ALERTE = 0
i = 0
# on recupere le nombre d'ALERTE disponible
all_ALERTE = len(myParser['entries'])
# dictionnaire contenant les informations sur les ALERTEs recupere a envoyer au serveur centrale
donnees = {}
# tant qu'on a pas recpere 5 ALERTE de type 'AVI', on boucle
# si on parcour toutes ALERTEs on arrete de boucler aussi
while i < all_ALERTE and nb_ALERTE < 5:
	# on recupere le type de l'ALERTE: AVI ou ACT, les act sont des bulletin d'info,
	# alors que les AVI sont des avis concernant des failles pouvant etre dangereuse pour les serveurs
	ALERTE = myParser['entries'][i]['title_detail']['value']
	# on recupere l'url de l'ALERTE
	url = myParser['entries'][i]['link']
	# l'ALERTE doit corespondre a un AVI
	ALERTE_type = r".*AVI.*"
	exp_ALERTE = re.compile(ALERTE_type)
	# si l'ALERTE est un avi
	if exp_ALERTE.search(ALERTE) is not None:
		# ALERTE a recupere
		# utilisation de beautiful soup pour extraire des infos depuis la page html qui contient des detailles sur l'ALERTE
		html = urlopen(url).read()
		soup = BeautifulSoup.BeautifulSoup(html)
		# on va recupere des infos a partir d'un tableau dans la page html de l'ALERTE
		table = soup.findAll('table')[2]
		# reference de l'ALERTE
		ref = (table.findAll('td')[2]).text
		# titre de l'ALERTE
		titre = (table.findAll('td')[4]).text
		# date de publication de l'ALERTE
		date_ALERTE = myParser['feed']['updated']
		# on redefinie le format de la date pour pouvoir l'utiliser plus facilement
		date_ALERTE = datetime.datetime.strptime(date_ALERTE, '%a, %d %b %Y %H:%M:%S CEST').strftime('%Y-%m-%d %H:%M:%S')
		donnees = {'ref_ALERTE': ref, 'titre_ALERTE': titre, 'date_ALERTE': date_ALERTE, 'url_ALERTE': url}
		# on insert dans la table ALERTE la nouvelle ALERTE, 
		# et envoi un mail a tous les administrateur pour leur indiquer qu'une nouvelle faille a ete publie. 
		methods = 'insert_ALERTE'
		url = adresse + methods
		r = requests.post(url, data = donnees)
		print(r.text)	
		nb_ALERTE = nb_ALERTE + 1
	i = i + 1

print('fin du scritpe')	