#!/usr/bin/bash

cp -Rfp $1 $2		